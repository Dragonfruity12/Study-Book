﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.NewToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.OpenToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.SaveToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.PrintToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.toolStripSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.CutToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.CopyToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.PasteToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.toolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.HelpToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.RichTextBox2 = New System.Windows.Forms.RichTextBox()
        Me.ToolStrip2 = New System.Windows.Forms.ToolStrip()
        Me.NewToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.OpenToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.SaveToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.PrintToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.toolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.CutToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.CopyToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.PasteToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.toolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.HelpToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.RichTextBox3 = New System.Windows.Forms.RichTextBox()
        Me.ToolStrip3 = New System.Windows.Forms.ToolStrip()
        Me.NewToolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.OpenToolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.SaveToolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.PrintToolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.toolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.CutToolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.CopyToolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.PasteToolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.toolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.HelpToolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.RichTextBox4 = New System.Windows.Forms.RichTextBox()
        Me.ToolStrip4 = New System.Windows.Forms.ToolStrip()
        Me.NewToolStripButton3 = New System.Windows.Forms.ToolStripButton()
        Me.OpenToolStripButton3 = New System.Windows.Forms.ToolStripButton()
        Me.SaveToolStripButton3 = New System.Windows.Forms.ToolStripButton()
        Me.PrintToolStripButton3 = New System.Windows.Forms.ToolStripButton()
        Me.toolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.CutToolStripButton3 = New System.Windows.Forms.ToolStripButton()
        Me.CopyToolStripButton3 = New System.Windows.Forms.ToolStripButton()
        Me.PasteToolStripButton3 = New System.Windows.Forms.ToolStripButton()
        Me.toolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.HelpToolStripButton3 = New System.Windows.Forms.ToolStripButton()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.RichTextBox5 = New System.Windows.Forms.RichTextBox()
        Me.ToolStrip5 = New System.Windows.Forms.ToolStrip()
        Me.NewToolStripButton4 = New System.Windows.Forms.ToolStripButton()
        Me.OpenToolStripButton4 = New System.Windows.Forms.ToolStripButton()
        Me.SaveToolStripButton4 = New System.Windows.Forms.ToolStripButton()
        Me.PrintToolStripButton4 = New System.Windows.Forms.ToolStripButton()
        Me.toolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator()
        Me.CutToolStripButton4 = New System.Windows.Forms.ToolStripButton()
        Me.CopyToolStripButton4 = New System.Windows.Forms.ToolStripButton()
        Me.PasteToolStripButton4 = New System.Windows.Forms.ToolStripButton()
        Me.toolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator()
        Me.HelpToolStripButton4 = New System.Windows.Forms.ToolStripButton()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.RichTextBox6 = New System.Windows.Forms.RichTextBox()
        Me.ToolStrip6 = New System.Windows.Forms.ToolStrip()
        Me.NewToolStripButton5 = New System.Windows.Forms.ToolStripButton()
        Me.OpenToolStripButton5 = New System.Windows.Forms.ToolStripButton()
        Me.SaveToolStripButton5 = New System.Windows.Forms.ToolStripButton()
        Me.PrintToolStripButton5 = New System.Windows.Forms.ToolStripButton()
        Me.toolStripSeparator10 = New System.Windows.Forms.ToolStripSeparator()
        Me.CutToolStripButton5 = New System.Windows.Forms.ToolStripButton()
        Me.CopyToolStripButton5 = New System.Windows.Forms.ToolStripButton()
        Me.PasteToolStripButton5 = New System.Windows.Forms.ToolStripButton()
        Me.toolStripSeparator11 = New System.Windows.Forms.ToolStripSeparator()
        Me.HelpToolStripButton5 = New System.Windows.Forms.ToolStripButton()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.RichTextBox7 = New System.Windows.Forms.RichTextBox()
        Me.ToolStrip7 = New System.Windows.Forms.ToolStrip()
        Me.NewToolStripButton6 = New System.Windows.Forms.ToolStripButton()
        Me.OpenToolStripButton6 = New System.Windows.Forms.ToolStripButton()
        Me.SaveToolStripButton6 = New System.Windows.Forms.ToolStripButton()
        Me.PrintToolStripButton6 = New System.Windows.Forms.ToolStripButton()
        Me.toolStripSeparator12 = New System.Windows.Forms.ToolStripSeparator()
        Me.CutToolStripButton6 = New System.Windows.Forms.ToolStripButton()
        Me.CopyToolStripButton6 = New System.Windows.Forms.ToolStripButton()
        Me.PasteToolStripButton6 = New System.Windows.Forms.ToolStripButton()
        Me.toolStripSeparator13 = New System.Windows.Forms.ToolStripSeparator()
        Me.HelpToolStripButton6 = New System.Windows.Forms.ToolStripButton()
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.RichTextBox8 = New System.Windows.Forms.RichTextBox()
        Me.ToolStrip8 = New System.Windows.Forms.ToolStrip()
        Me.NewToolStripButton7 = New System.Windows.Forms.ToolStripButton()
        Me.OpenToolStripButton7 = New System.Windows.Forms.ToolStripButton()
        Me.SaveToolStripButton7 = New System.Windows.Forms.ToolStripButton()
        Me.PrintToolStripButton7 = New System.Windows.Forms.ToolStripButton()
        Me.toolStripSeparator14 = New System.Windows.Forms.ToolStripSeparator()
        Me.CutToolStripButton7 = New System.Windows.Forms.ToolStripButton()
        Me.CopyToolStripButton7 = New System.Windows.Forms.ToolStripButton()
        Me.PasteToolStripButton7 = New System.Windows.Forms.ToolStripButton()
        Me.toolStripSeparator15 = New System.Windows.Forms.ToolStripSeparator()
        Me.HelpToolStripButton7 = New System.Windows.Forms.ToolStripButton()
        Me.TabPage10 = New System.Windows.Forms.TabPage()
        Me.RichTextBox9 = New System.Windows.Forms.RichTextBox()
        Me.ToolStrip9 = New System.Windows.Forms.ToolStrip()
        Me.NewToolStripButton8 = New System.Windows.Forms.ToolStripButton()
        Me.OpenToolStripButton8 = New System.Windows.Forms.ToolStripButton()
        Me.SaveToolStripButton8 = New System.Windows.Forms.ToolStripButton()
        Me.PrintToolStripButton8 = New System.Windows.Forms.ToolStripButton()
        Me.toolStripSeparator16 = New System.Windows.Forms.ToolStripSeparator()
        Me.CutToolStripButton8 = New System.Windows.Forms.ToolStripButton()
        Me.CopyToolStripButton8 = New System.Windows.Forms.ToolStripButton()
        Me.PasteToolStripButton8 = New System.Windows.Forms.ToolStripButton()
        Me.toolStripSeparator17 = New System.Windows.Forms.ToolStripSeparator()
        Me.HelpToolStripButton8 = New System.Windows.Forms.ToolStripButton()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.OpenFileDialog2 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog2 = New System.Windows.Forms.SaveFileDialog()
        Me.OpenFileDialog3 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog3 = New System.Windows.Forms.SaveFileDialog()
        Me.OpenFileDialog4 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog4 = New System.Windows.Forms.SaveFileDialog()
        Me.OpenFileDialog5 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog5 = New System.Windows.Forms.SaveFileDialog()
        Me.OpenFileDialog6 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog6 = New System.Windows.Forms.SaveFileDialog()
        Me.OpenFileDialog7 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog7 = New System.Windows.Forms.SaveFileDialog()
        Me.OpenFileDialog8 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog8 = New System.Windows.Forms.SaveFileDialog()
        Me.OpenFileDialog9 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog9 = New System.Windows.Forms.SaveFileDialog()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.MonthCalendar1 = New System.Windows.Forms.MonthCalendar()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.ToolStrip2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.ToolStrip3.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.ToolStrip4.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.ToolStrip5.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.ToolStrip6.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        Me.ToolStrip7.SuspendLayout()
        Me.TabPage9.SuspendLayout()
        Me.ToolStrip8.SuspendLayout()
        Me.TabPage10.SuspendLayout()
        Me.ToolStrip9.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.TabPage7)
        Me.TabControl1.Controls.Add(Me.TabPage8)
        Me.TabControl1.Controls.Add(Me.TabPage9)
        Me.TabControl1.Controls.Add(Me.TabPage10)
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1036, 616)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Button2)
        Me.TabPage1.Controls.Add(Me.MonthCalendar1)
        Me.TabPage1.Controls.Add(Me.Button1)
        Me.TabPage1.Controls.Add(Me.ToolStrip1)
        Me.TabPage1.Controls.Add(Me.RichTextBox1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1028, 590)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Mathematics"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripButton, Me.OpenToolStripButton, Me.SaveToolStripButton, Me.PrintToolStripButton, Me.toolStripSeparator, Me.CutToolStripButton, Me.CopyToolStripButton, Me.PasteToolStripButton, Me.toolStripSeparator1, Me.HelpToolStripButton})
        Me.ToolStrip1.Location = New System.Drawing.Point(3, 3)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(1022, 25)
        Me.ToolStrip1.TabIndex = 1
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'NewToolStripButton
        '
        Me.NewToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.NewToolStripButton.Image = CType(resources.GetObject("NewToolStripButton.Image"), System.Drawing.Image)
        Me.NewToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.NewToolStripButton.Name = "NewToolStripButton"
        Me.NewToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.NewToolStripButton.Text = "&New"
        '
        'OpenToolStripButton
        '
        Me.OpenToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.OpenToolStripButton.Image = CType(resources.GetObject("OpenToolStripButton.Image"), System.Drawing.Image)
        Me.OpenToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.OpenToolStripButton.Name = "OpenToolStripButton"
        Me.OpenToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.OpenToolStripButton.Text = "&Open"
        '
        'SaveToolStripButton
        '
        Me.SaveToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SaveToolStripButton.Image = CType(resources.GetObject("SaveToolStripButton.Image"), System.Drawing.Image)
        Me.SaveToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SaveToolStripButton.Name = "SaveToolStripButton"
        Me.SaveToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.SaveToolStripButton.Text = "&Save"
        '
        'PrintToolStripButton
        '
        Me.PrintToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PrintToolStripButton.Image = CType(resources.GetObject("PrintToolStripButton.Image"), System.Drawing.Image)
        Me.PrintToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PrintToolStripButton.Name = "PrintToolStripButton"
        Me.PrintToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.PrintToolStripButton.Text = "&Print"
        '
        'toolStripSeparator
        '
        Me.toolStripSeparator.Name = "toolStripSeparator"
        Me.toolStripSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'CutToolStripButton
        '
        Me.CutToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CutToolStripButton.Image = CType(resources.GetObject("CutToolStripButton.Image"), System.Drawing.Image)
        Me.CutToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CutToolStripButton.Name = "CutToolStripButton"
        Me.CutToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.CutToolStripButton.Text = "C&ut"
        '
        'CopyToolStripButton
        '
        Me.CopyToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CopyToolStripButton.Image = CType(resources.GetObject("CopyToolStripButton.Image"), System.Drawing.Image)
        Me.CopyToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CopyToolStripButton.Name = "CopyToolStripButton"
        Me.CopyToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.CopyToolStripButton.Text = "&Copy"
        '
        'PasteToolStripButton
        '
        Me.PasteToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PasteToolStripButton.Image = CType(resources.GetObject("PasteToolStripButton.Image"), System.Drawing.Image)
        Me.PasteToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PasteToolStripButton.Name = "PasteToolStripButton"
        Me.PasteToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.PasteToolStripButton.Text = "&Paste"
        '
        'toolStripSeparator1
        '
        Me.toolStripSeparator1.Name = "toolStripSeparator1"
        Me.toolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'HelpToolStripButton
        '
        Me.HelpToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.HelpToolStripButton.Image = CType(resources.GetObject("HelpToolStripButton.Image"), System.Drawing.Image)
        Me.HelpToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.HelpToolStripButton.Name = "HelpToolStripButton"
        Me.HelpToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.HelpToolStripButton.Text = "He&lp"
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RichTextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox1.Location = New System.Drawing.Point(0, 31)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(1025, 559)
        Me.RichTextBox1.TabIndex = 0
        Me.RichTextBox1.Text = ""
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.RichTextBox2)
        Me.TabPage2.Controls.Add(Me.ToolStrip2)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1028, 590)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Biology"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'RichTextBox2
        '
        Me.RichTextBox2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RichTextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox2.Location = New System.Drawing.Point(0, 31)
        Me.RichTextBox2.Name = "RichTextBox2"
        Me.RichTextBox2.Size = New System.Drawing.Size(1025, 559)
        Me.RichTextBox2.TabIndex = 1
        Me.RichTextBox2.Text = ""
        '
        'ToolStrip2
        '
        Me.ToolStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripButton1, Me.OpenToolStripButton1, Me.SaveToolStripButton1, Me.PrintToolStripButton1, Me.toolStripSeparator2, Me.CutToolStripButton1, Me.CopyToolStripButton1, Me.PasteToolStripButton1, Me.toolStripSeparator3, Me.HelpToolStripButton1})
        Me.ToolStrip2.Location = New System.Drawing.Point(3, 3)
        Me.ToolStrip2.Name = "ToolStrip2"
        Me.ToolStrip2.Size = New System.Drawing.Size(1022, 25)
        Me.ToolStrip2.TabIndex = 0
        Me.ToolStrip2.Text = "ToolStrip2"
        '
        'NewToolStripButton1
        '
        Me.NewToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.NewToolStripButton1.Image = CType(resources.GetObject("NewToolStripButton1.Image"), System.Drawing.Image)
        Me.NewToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.NewToolStripButton1.Name = "NewToolStripButton1"
        Me.NewToolStripButton1.Size = New System.Drawing.Size(23, 22)
        Me.NewToolStripButton1.Text = "&New"
        '
        'OpenToolStripButton1
        '
        Me.OpenToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.OpenToolStripButton1.Image = CType(resources.GetObject("OpenToolStripButton1.Image"), System.Drawing.Image)
        Me.OpenToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.OpenToolStripButton1.Name = "OpenToolStripButton1"
        Me.OpenToolStripButton1.Size = New System.Drawing.Size(23, 22)
        Me.OpenToolStripButton1.Text = "&Open"
        '
        'SaveToolStripButton1
        '
        Me.SaveToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SaveToolStripButton1.Image = CType(resources.GetObject("SaveToolStripButton1.Image"), System.Drawing.Image)
        Me.SaveToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SaveToolStripButton1.Name = "SaveToolStripButton1"
        Me.SaveToolStripButton1.Size = New System.Drawing.Size(23, 22)
        Me.SaveToolStripButton1.Text = "&Save"
        '
        'PrintToolStripButton1
        '
        Me.PrintToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PrintToolStripButton1.Image = CType(resources.GetObject("PrintToolStripButton1.Image"), System.Drawing.Image)
        Me.PrintToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PrintToolStripButton1.Name = "PrintToolStripButton1"
        Me.PrintToolStripButton1.Size = New System.Drawing.Size(23, 22)
        Me.PrintToolStripButton1.Text = "&Print"
        '
        'toolStripSeparator2
        '
        Me.toolStripSeparator2.Name = "toolStripSeparator2"
        Me.toolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'CutToolStripButton1
        '
        Me.CutToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CutToolStripButton1.Image = CType(resources.GetObject("CutToolStripButton1.Image"), System.Drawing.Image)
        Me.CutToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CutToolStripButton1.Name = "CutToolStripButton1"
        Me.CutToolStripButton1.Size = New System.Drawing.Size(23, 22)
        Me.CutToolStripButton1.Text = "C&ut"
        '
        'CopyToolStripButton1
        '
        Me.CopyToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CopyToolStripButton1.Image = CType(resources.GetObject("CopyToolStripButton1.Image"), System.Drawing.Image)
        Me.CopyToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CopyToolStripButton1.Name = "CopyToolStripButton1"
        Me.CopyToolStripButton1.Size = New System.Drawing.Size(23, 22)
        Me.CopyToolStripButton1.Text = "&Copy"
        '
        'PasteToolStripButton1
        '
        Me.PasteToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PasteToolStripButton1.Image = CType(resources.GetObject("PasteToolStripButton1.Image"), System.Drawing.Image)
        Me.PasteToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PasteToolStripButton1.Name = "PasteToolStripButton1"
        Me.PasteToolStripButton1.Size = New System.Drawing.Size(23, 22)
        Me.PasteToolStripButton1.Text = "&Paste"
        '
        'toolStripSeparator3
        '
        Me.toolStripSeparator3.Name = "toolStripSeparator3"
        Me.toolStripSeparator3.Size = New System.Drawing.Size(6, 25)
        '
        'HelpToolStripButton1
        '
        Me.HelpToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.HelpToolStripButton1.Image = CType(resources.GetObject("HelpToolStripButton1.Image"), System.Drawing.Image)
        Me.HelpToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.HelpToolStripButton1.Name = "HelpToolStripButton1"
        Me.HelpToolStripButton1.Size = New System.Drawing.Size(23, 22)
        Me.HelpToolStripButton1.Text = "He&lp"
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.RichTextBox3)
        Me.TabPage3.Controls.Add(Me.ToolStrip3)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(1028, 590)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "English"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'RichTextBox3
        '
        Me.RichTextBox3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RichTextBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox3.Location = New System.Drawing.Point(0, 31)
        Me.RichTextBox3.Name = "RichTextBox3"
        Me.RichTextBox3.Size = New System.Drawing.Size(1025, 559)
        Me.RichTextBox3.TabIndex = 1
        Me.RichTextBox3.Text = ""
        '
        'ToolStrip3
        '
        Me.ToolStrip3.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripButton2, Me.OpenToolStripButton2, Me.SaveToolStripButton2, Me.PrintToolStripButton2, Me.toolStripSeparator4, Me.CutToolStripButton2, Me.CopyToolStripButton2, Me.PasteToolStripButton2, Me.toolStripSeparator5, Me.HelpToolStripButton2})
        Me.ToolStrip3.Location = New System.Drawing.Point(3, 3)
        Me.ToolStrip3.Name = "ToolStrip3"
        Me.ToolStrip3.Size = New System.Drawing.Size(1022, 25)
        Me.ToolStrip3.TabIndex = 0
        Me.ToolStrip3.Text = "ToolStrip3"
        '
        'NewToolStripButton2
        '
        Me.NewToolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.NewToolStripButton2.Image = CType(resources.GetObject("NewToolStripButton2.Image"), System.Drawing.Image)
        Me.NewToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.NewToolStripButton2.Name = "NewToolStripButton2"
        Me.NewToolStripButton2.Size = New System.Drawing.Size(23, 22)
        Me.NewToolStripButton2.Text = "&New"
        '
        'OpenToolStripButton2
        '
        Me.OpenToolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.OpenToolStripButton2.Image = CType(resources.GetObject("OpenToolStripButton2.Image"), System.Drawing.Image)
        Me.OpenToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.OpenToolStripButton2.Name = "OpenToolStripButton2"
        Me.OpenToolStripButton2.Size = New System.Drawing.Size(23, 22)
        Me.OpenToolStripButton2.Text = "&Open"
        '
        'SaveToolStripButton2
        '
        Me.SaveToolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SaveToolStripButton2.Image = CType(resources.GetObject("SaveToolStripButton2.Image"), System.Drawing.Image)
        Me.SaveToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SaveToolStripButton2.Name = "SaveToolStripButton2"
        Me.SaveToolStripButton2.Size = New System.Drawing.Size(23, 22)
        Me.SaveToolStripButton2.Text = "&Save"
        '
        'PrintToolStripButton2
        '
        Me.PrintToolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PrintToolStripButton2.Image = CType(resources.GetObject("PrintToolStripButton2.Image"), System.Drawing.Image)
        Me.PrintToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PrintToolStripButton2.Name = "PrintToolStripButton2"
        Me.PrintToolStripButton2.Size = New System.Drawing.Size(23, 22)
        Me.PrintToolStripButton2.Text = "&Print"
        '
        'toolStripSeparator4
        '
        Me.toolStripSeparator4.Name = "toolStripSeparator4"
        Me.toolStripSeparator4.Size = New System.Drawing.Size(6, 25)
        '
        'CutToolStripButton2
        '
        Me.CutToolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CutToolStripButton2.Image = CType(resources.GetObject("CutToolStripButton2.Image"), System.Drawing.Image)
        Me.CutToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CutToolStripButton2.Name = "CutToolStripButton2"
        Me.CutToolStripButton2.Size = New System.Drawing.Size(23, 22)
        Me.CutToolStripButton2.Text = "C&ut"
        '
        'CopyToolStripButton2
        '
        Me.CopyToolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CopyToolStripButton2.Image = CType(resources.GetObject("CopyToolStripButton2.Image"), System.Drawing.Image)
        Me.CopyToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CopyToolStripButton2.Name = "CopyToolStripButton2"
        Me.CopyToolStripButton2.Size = New System.Drawing.Size(23, 22)
        Me.CopyToolStripButton2.Text = "&Copy"
        '
        'PasteToolStripButton2
        '
        Me.PasteToolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PasteToolStripButton2.Image = CType(resources.GetObject("PasteToolStripButton2.Image"), System.Drawing.Image)
        Me.PasteToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PasteToolStripButton2.Name = "PasteToolStripButton2"
        Me.PasteToolStripButton2.Size = New System.Drawing.Size(23, 22)
        Me.PasteToolStripButton2.Text = "&Paste"
        '
        'toolStripSeparator5
        '
        Me.toolStripSeparator5.Name = "toolStripSeparator5"
        Me.toolStripSeparator5.Size = New System.Drawing.Size(6, 25)
        '
        'HelpToolStripButton2
        '
        Me.HelpToolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.HelpToolStripButton2.Image = CType(resources.GetObject("HelpToolStripButton2.Image"), System.Drawing.Image)
        Me.HelpToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.HelpToolStripButton2.Name = "HelpToolStripButton2"
        Me.HelpToolStripButton2.Size = New System.Drawing.Size(23, 22)
        Me.HelpToolStripButton2.Text = "He&lp"
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.RichTextBox4)
        Me.TabPage5.Controls.Add(Me.ToolStrip4)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(1028, 590)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "History"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'RichTextBox4
        '
        Me.RichTextBox4.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RichTextBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox4.Location = New System.Drawing.Point(0, 31)
        Me.RichTextBox4.Name = "RichTextBox4"
        Me.RichTextBox4.Size = New System.Drawing.Size(1025, 559)
        Me.RichTextBox4.TabIndex = 1
        Me.RichTextBox4.Text = ""
        '
        'ToolStrip4
        '
        Me.ToolStrip4.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripButton3, Me.OpenToolStripButton3, Me.SaveToolStripButton3, Me.PrintToolStripButton3, Me.toolStripSeparator6, Me.CutToolStripButton3, Me.CopyToolStripButton3, Me.PasteToolStripButton3, Me.toolStripSeparator7, Me.HelpToolStripButton3})
        Me.ToolStrip4.Location = New System.Drawing.Point(3, 3)
        Me.ToolStrip4.Name = "ToolStrip4"
        Me.ToolStrip4.Size = New System.Drawing.Size(1022, 25)
        Me.ToolStrip4.TabIndex = 0
        Me.ToolStrip4.Text = "ToolStrip4"
        '
        'NewToolStripButton3
        '
        Me.NewToolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.NewToolStripButton3.Image = CType(resources.GetObject("NewToolStripButton3.Image"), System.Drawing.Image)
        Me.NewToolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.NewToolStripButton3.Name = "NewToolStripButton3"
        Me.NewToolStripButton3.Size = New System.Drawing.Size(23, 22)
        Me.NewToolStripButton3.Text = "&New"
        '
        'OpenToolStripButton3
        '
        Me.OpenToolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.OpenToolStripButton3.Image = CType(resources.GetObject("OpenToolStripButton3.Image"), System.Drawing.Image)
        Me.OpenToolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.OpenToolStripButton3.Name = "OpenToolStripButton3"
        Me.OpenToolStripButton3.Size = New System.Drawing.Size(23, 22)
        Me.OpenToolStripButton3.Text = "&Open"
        '
        'SaveToolStripButton3
        '
        Me.SaveToolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SaveToolStripButton3.Image = CType(resources.GetObject("SaveToolStripButton3.Image"), System.Drawing.Image)
        Me.SaveToolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SaveToolStripButton3.Name = "SaveToolStripButton3"
        Me.SaveToolStripButton3.Size = New System.Drawing.Size(23, 22)
        Me.SaveToolStripButton3.Text = "&Save"
        '
        'PrintToolStripButton3
        '
        Me.PrintToolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PrintToolStripButton3.Image = CType(resources.GetObject("PrintToolStripButton3.Image"), System.Drawing.Image)
        Me.PrintToolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PrintToolStripButton3.Name = "PrintToolStripButton3"
        Me.PrintToolStripButton3.Size = New System.Drawing.Size(23, 22)
        Me.PrintToolStripButton3.Text = "&Print"
        '
        'toolStripSeparator6
        '
        Me.toolStripSeparator6.Name = "toolStripSeparator6"
        Me.toolStripSeparator6.Size = New System.Drawing.Size(6, 25)
        '
        'CutToolStripButton3
        '
        Me.CutToolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CutToolStripButton3.Image = CType(resources.GetObject("CutToolStripButton3.Image"), System.Drawing.Image)
        Me.CutToolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CutToolStripButton3.Name = "CutToolStripButton3"
        Me.CutToolStripButton3.Size = New System.Drawing.Size(23, 22)
        Me.CutToolStripButton3.Text = "C&ut"
        '
        'CopyToolStripButton3
        '
        Me.CopyToolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CopyToolStripButton3.Image = CType(resources.GetObject("CopyToolStripButton3.Image"), System.Drawing.Image)
        Me.CopyToolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CopyToolStripButton3.Name = "CopyToolStripButton3"
        Me.CopyToolStripButton3.Size = New System.Drawing.Size(23, 22)
        Me.CopyToolStripButton3.Text = "&Copy"
        '
        'PasteToolStripButton3
        '
        Me.PasteToolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PasteToolStripButton3.Image = CType(resources.GetObject("PasteToolStripButton3.Image"), System.Drawing.Image)
        Me.PasteToolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PasteToolStripButton3.Name = "PasteToolStripButton3"
        Me.PasteToolStripButton3.Size = New System.Drawing.Size(23, 22)
        Me.PasteToolStripButton3.Text = "&Paste"
        '
        'toolStripSeparator7
        '
        Me.toolStripSeparator7.Name = "toolStripSeparator7"
        Me.toolStripSeparator7.Size = New System.Drawing.Size(6, 25)
        '
        'HelpToolStripButton3
        '
        Me.HelpToolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.HelpToolStripButton3.Image = CType(resources.GetObject("HelpToolStripButton3.Image"), System.Drawing.Image)
        Me.HelpToolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.HelpToolStripButton3.Name = "HelpToolStripButton3"
        Me.HelpToolStripButton3.Size = New System.Drawing.Size(23, 22)
        Me.HelpToolStripButton3.Text = "He&lp"
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.RichTextBox5)
        Me.TabPage6.Controls.Add(Me.ToolStrip5)
        Me.TabPage6.Location = New System.Drawing.Point(4, 22)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(1028, 590)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "Music"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'RichTextBox5
        '
        Me.RichTextBox5.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RichTextBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox5.Location = New System.Drawing.Point(0, 31)
        Me.RichTextBox5.Name = "RichTextBox5"
        Me.RichTextBox5.Size = New System.Drawing.Size(1025, 559)
        Me.RichTextBox5.TabIndex = 1
        Me.RichTextBox5.Text = ""
        '
        'ToolStrip5
        '
        Me.ToolStrip5.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripButton4, Me.OpenToolStripButton4, Me.SaveToolStripButton4, Me.PrintToolStripButton4, Me.toolStripSeparator8, Me.CutToolStripButton4, Me.CopyToolStripButton4, Me.PasteToolStripButton4, Me.toolStripSeparator9, Me.HelpToolStripButton4})
        Me.ToolStrip5.Location = New System.Drawing.Point(3, 3)
        Me.ToolStrip5.Name = "ToolStrip5"
        Me.ToolStrip5.Size = New System.Drawing.Size(1022, 25)
        Me.ToolStrip5.TabIndex = 0
        Me.ToolStrip5.Text = "ToolStrip5"
        '
        'NewToolStripButton4
        '
        Me.NewToolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.NewToolStripButton4.Image = CType(resources.GetObject("NewToolStripButton4.Image"), System.Drawing.Image)
        Me.NewToolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.NewToolStripButton4.Name = "NewToolStripButton4"
        Me.NewToolStripButton4.Size = New System.Drawing.Size(23, 22)
        Me.NewToolStripButton4.Text = "&New"
        '
        'OpenToolStripButton4
        '
        Me.OpenToolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.OpenToolStripButton4.Image = CType(resources.GetObject("OpenToolStripButton4.Image"), System.Drawing.Image)
        Me.OpenToolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.OpenToolStripButton4.Name = "OpenToolStripButton4"
        Me.OpenToolStripButton4.Size = New System.Drawing.Size(23, 22)
        Me.OpenToolStripButton4.Text = "&Open"
        '
        'SaveToolStripButton4
        '
        Me.SaveToolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SaveToolStripButton4.Image = CType(resources.GetObject("SaveToolStripButton4.Image"), System.Drawing.Image)
        Me.SaveToolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SaveToolStripButton4.Name = "SaveToolStripButton4"
        Me.SaveToolStripButton4.Size = New System.Drawing.Size(23, 22)
        Me.SaveToolStripButton4.Text = "&Save"
        '
        'PrintToolStripButton4
        '
        Me.PrintToolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PrintToolStripButton4.Image = CType(resources.GetObject("PrintToolStripButton4.Image"), System.Drawing.Image)
        Me.PrintToolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PrintToolStripButton4.Name = "PrintToolStripButton4"
        Me.PrintToolStripButton4.Size = New System.Drawing.Size(23, 22)
        Me.PrintToolStripButton4.Text = "&Print"
        '
        'toolStripSeparator8
        '
        Me.toolStripSeparator8.Name = "toolStripSeparator8"
        Me.toolStripSeparator8.Size = New System.Drawing.Size(6, 25)
        '
        'CutToolStripButton4
        '
        Me.CutToolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CutToolStripButton4.Image = CType(resources.GetObject("CutToolStripButton4.Image"), System.Drawing.Image)
        Me.CutToolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CutToolStripButton4.Name = "CutToolStripButton4"
        Me.CutToolStripButton4.Size = New System.Drawing.Size(23, 22)
        Me.CutToolStripButton4.Text = "C&ut"
        '
        'CopyToolStripButton4
        '
        Me.CopyToolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CopyToolStripButton4.Image = CType(resources.GetObject("CopyToolStripButton4.Image"), System.Drawing.Image)
        Me.CopyToolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CopyToolStripButton4.Name = "CopyToolStripButton4"
        Me.CopyToolStripButton4.Size = New System.Drawing.Size(23, 22)
        Me.CopyToolStripButton4.Text = "&Copy"
        '
        'PasteToolStripButton4
        '
        Me.PasteToolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PasteToolStripButton4.Image = CType(resources.GetObject("PasteToolStripButton4.Image"), System.Drawing.Image)
        Me.PasteToolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PasteToolStripButton4.Name = "PasteToolStripButton4"
        Me.PasteToolStripButton4.Size = New System.Drawing.Size(23, 22)
        Me.PasteToolStripButton4.Text = "&Paste"
        '
        'toolStripSeparator9
        '
        Me.toolStripSeparator9.Name = "toolStripSeparator9"
        Me.toolStripSeparator9.Size = New System.Drawing.Size(6, 25)
        '
        'HelpToolStripButton4
        '
        Me.HelpToolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.HelpToolStripButton4.Image = CType(resources.GetObject("HelpToolStripButton4.Image"), System.Drawing.Image)
        Me.HelpToolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.HelpToolStripButton4.Name = "HelpToolStripButton4"
        Me.HelpToolStripButton4.Size = New System.Drawing.Size(23, 22)
        Me.HelpToolStripButton4.Text = "He&lp"
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.RichTextBox6)
        Me.TabPage7.Controls.Add(Me.ToolStrip6)
        Me.TabPage7.Location = New System.Drawing.Point(4, 22)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TabPage7.Size = New System.Drawing.Size(1028, 590)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "Computer Science"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'RichTextBox6
        '
        Me.RichTextBox6.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RichTextBox6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox6.Location = New System.Drawing.Point(0, 31)
        Me.RichTextBox6.Name = "RichTextBox6"
        Me.RichTextBox6.Size = New System.Drawing.Size(1025, 559)
        Me.RichTextBox6.TabIndex = 1
        Me.RichTextBox6.Text = ""
        '
        'ToolStrip6
        '
        Me.ToolStrip6.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripButton5, Me.OpenToolStripButton5, Me.SaveToolStripButton5, Me.PrintToolStripButton5, Me.toolStripSeparator10, Me.CutToolStripButton5, Me.CopyToolStripButton5, Me.PasteToolStripButton5, Me.toolStripSeparator11, Me.HelpToolStripButton5})
        Me.ToolStrip6.Location = New System.Drawing.Point(3, 3)
        Me.ToolStrip6.Name = "ToolStrip6"
        Me.ToolStrip6.Size = New System.Drawing.Size(1022, 25)
        Me.ToolStrip6.TabIndex = 0
        Me.ToolStrip6.Text = "ToolStrip6"
        '
        'NewToolStripButton5
        '
        Me.NewToolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.NewToolStripButton5.Image = CType(resources.GetObject("NewToolStripButton5.Image"), System.Drawing.Image)
        Me.NewToolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.NewToolStripButton5.Name = "NewToolStripButton5"
        Me.NewToolStripButton5.Size = New System.Drawing.Size(23, 22)
        Me.NewToolStripButton5.Text = "&New"
        '
        'OpenToolStripButton5
        '
        Me.OpenToolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.OpenToolStripButton5.Image = CType(resources.GetObject("OpenToolStripButton5.Image"), System.Drawing.Image)
        Me.OpenToolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.OpenToolStripButton5.Name = "OpenToolStripButton5"
        Me.OpenToolStripButton5.Size = New System.Drawing.Size(23, 22)
        Me.OpenToolStripButton5.Text = "&Open"
        '
        'SaveToolStripButton5
        '
        Me.SaveToolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SaveToolStripButton5.Image = CType(resources.GetObject("SaveToolStripButton5.Image"), System.Drawing.Image)
        Me.SaveToolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SaveToolStripButton5.Name = "SaveToolStripButton5"
        Me.SaveToolStripButton5.Size = New System.Drawing.Size(23, 22)
        Me.SaveToolStripButton5.Text = "&Save"
        '
        'PrintToolStripButton5
        '
        Me.PrintToolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PrintToolStripButton5.Image = CType(resources.GetObject("PrintToolStripButton5.Image"), System.Drawing.Image)
        Me.PrintToolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PrintToolStripButton5.Name = "PrintToolStripButton5"
        Me.PrintToolStripButton5.Size = New System.Drawing.Size(23, 22)
        Me.PrintToolStripButton5.Text = "&Print"
        '
        'toolStripSeparator10
        '
        Me.toolStripSeparator10.Name = "toolStripSeparator10"
        Me.toolStripSeparator10.Size = New System.Drawing.Size(6, 25)
        '
        'CutToolStripButton5
        '
        Me.CutToolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CutToolStripButton5.Image = CType(resources.GetObject("CutToolStripButton5.Image"), System.Drawing.Image)
        Me.CutToolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CutToolStripButton5.Name = "CutToolStripButton5"
        Me.CutToolStripButton5.Size = New System.Drawing.Size(23, 22)
        Me.CutToolStripButton5.Text = "C&ut"
        '
        'CopyToolStripButton5
        '
        Me.CopyToolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CopyToolStripButton5.Image = CType(resources.GetObject("CopyToolStripButton5.Image"), System.Drawing.Image)
        Me.CopyToolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CopyToolStripButton5.Name = "CopyToolStripButton5"
        Me.CopyToolStripButton5.Size = New System.Drawing.Size(23, 22)
        Me.CopyToolStripButton5.Text = "&Copy"
        '
        'PasteToolStripButton5
        '
        Me.PasteToolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PasteToolStripButton5.Image = CType(resources.GetObject("PasteToolStripButton5.Image"), System.Drawing.Image)
        Me.PasteToolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PasteToolStripButton5.Name = "PasteToolStripButton5"
        Me.PasteToolStripButton5.Size = New System.Drawing.Size(23, 22)
        Me.PasteToolStripButton5.Text = "&Paste"
        '
        'toolStripSeparator11
        '
        Me.toolStripSeparator11.Name = "toolStripSeparator11"
        Me.toolStripSeparator11.Size = New System.Drawing.Size(6, 25)
        '
        'HelpToolStripButton5
        '
        Me.HelpToolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.HelpToolStripButton5.Image = CType(resources.GetObject("HelpToolStripButton5.Image"), System.Drawing.Image)
        Me.HelpToolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.HelpToolStripButton5.Name = "HelpToolStripButton5"
        Me.HelpToolStripButton5.Size = New System.Drawing.Size(23, 22)
        Me.HelpToolStripButton5.Text = "He&lp"
        '
        'TabPage8
        '
        Me.TabPage8.Controls.Add(Me.RichTextBox7)
        Me.TabPage8.Controls.Add(Me.ToolStrip7)
        Me.TabPage8.Location = New System.Drawing.Point(4, 22)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage8.Size = New System.Drawing.Size(1028, 590)
        Me.TabPage8.TabIndex = 7
        Me.TabPage8.Text = "Information Technology"
        Me.TabPage8.UseVisualStyleBackColor = True
        '
        'RichTextBox7
        '
        Me.RichTextBox7.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox7.Location = New System.Drawing.Point(0, 31)
        Me.RichTextBox7.Name = "RichTextBox7"
        Me.RichTextBox7.Size = New System.Drawing.Size(1025, 559)
        Me.RichTextBox7.TabIndex = 1
        Me.RichTextBox7.Text = ""
        '
        'ToolStrip7
        '
        Me.ToolStrip7.AutoSize = False
        Me.ToolStrip7.Dock = System.Windows.Forms.DockStyle.None
        Me.ToolStrip7.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripButton6, Me.OpenToolStripButton6, Me.SaveToolStripButton6, Me.PrintToolStripButton6, Me.toolStripSeparator12, Me.CutToolStripButton6, Me.CopyToolStripButton6, Me.PasteToolStripButton6, Me.toolStripSeparator13, Me.HelpToolStripButton6})
        Me.ToolStrip7.Location = New System.Drawing.Point(3, 3)
        Me.ToolStrip7.Name = "ToolStrip7"
        Me.ToolStrip7.Size = New System.Drawing.Size(1022, 25)
        Me.ToolStrip7.TabIndex = 0
        Me.ToolStrip7.Text = "ToolStrip7"
        '
        'NewToolStripButton6
        '
        Me.NewToolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.NewToolStripButton6.Image = CType(resources.GetObject("NewToolStripButton6.Image"), System.Drawing.Image)
        Me.NewToolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.NewToolStripButton6.Name = "NewToolStripButton6"
        Me.NewToolStripButton6.Size = New System.Drawing.Size(23, 22)
        Me.NewToolStripButton6.Text = "&New"
        '
        'OpenToolStripButton6
        '
        Me.OpenToolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.OpenToolStripButton6.Image = CType(resources.GetObject("OpenToolStripButton6.Image"), System.Drawing.Image)
        Me.OpenToolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.OpenToolStripButton6.Name = "OpenToolStripButton6"
        Me.OpenToolStripButton6.Size = New System.Drawing.Size(23, 22)
        Me.OpenToolStripButton6.Text = "&Open"
        '
        'SaveToolStripButton6
        '
        Me.SaveToolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SaveToolStripButton6.Image = CType(resources.GetObject("SaveToolStripButton6.Image"), System.Drawing.Image)
        Me.SaveToolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SaveToolStripButton6.Name = "SaveToolStripButton6"
        Me.SaveToolStripButton6.Size = New System.Drawing.Size(23, 22)
        Me.SaveToolStripButton6.Text = "&Save"
        '
        'PrintToolStripButton6
        '
        Me.PrintToolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PrintToolStripButton6.Image = CType(resources.GetObject("PrintToolStripButton6.Image"), System.Drawing.Image)
        Me.PrintToolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PrintToolStripButton6.Name = "PrintToolStripButton6"
        Me.PrintToolStripButton6.Size = New System.Drawing.Size(23, 22)
        Me.PrintToolStripButton6.Text = "&Print"
        '
        'toolStripSeparator12
        '
        Me.toolStripSeparator12.Name = "toolStripSeparator12"
        Me.toolStripSeparator12.Size = New System.Drawing.Size(6, 25)
        '
        'CutToolStripButton6
        '
        Me.CutToolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CutToolStripButton6.Image = CType(resources.GetObject("CutToolStripButton6.Image"), System.Drawing.Image)
        Me.CutToolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CutToolStripButton6.Name = "CutToolStripButton6"
        Me.CutToolStripButton6.Size = New System.Drawing.Size(23, 22)
        Me.CutToolStripButton6.Text = "C&ut"
        '
        'CopyToolStripButton6
        '
        Me.CopyToolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CopyToolStripButton6.Image = CType(resources.GetObject("CopyToolStripButton6.Image"), System.Drawing.Image)
        Me.CopyToolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CopyToolStripButton6.Name = "CopyToolStripButton6"
        Me.CopyToolStripButton6.Size = New System.Drawing.Size(23, 22)
        Me.CopyToolStripButton6.Text = "&Copy"
        '
        'PasteToolStripButton6
        '
        Me.PasteToolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PasteToolStripButton6.Image = CType(resources.GetObject("PasteToolStripButton6.Image"), System.Drawing.Image)
        Me.PasteToolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PasteToolStripButton6.Name = "PasteToolStripButton6"
        Me.PasteToolStripButton6.Size = New System.Drawing.Size(23, 22)
        Me.PasteToolStripButton6.Text = "&Paste"
        '
        'toolStripSeparator13
        '
        Me.toolStripSeparator13.Name = "toolStripSeparator13"
        Me.toolStripSeparator13.Size = New System.Drawing.Size(6, 25)
        '
        'HelpToolStripButton6
        '
        Me.HelpToolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.HelpToolStripButton6.Image = CType(resources.GetObject("HelpToolStripButton6.Image"), System.Drawing.Image)
        Me.HelpToolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.HelpToolStripButton6.Name = "HelpToolStripButton6"
        Me.HelpToolStripButton6.Size = New System.Drawing.Size(23, 22)
        Me.HelpToolStripButton6.Text = "He&lp"
        '
        'TabPage9
        '
        Me.TabPage9.Controls.Add(Me.RichTextBox8)
        Me.TabPage9.Controls.Add(Me.ToolStrip8)
        Me.TabPage9.Location = New System.Drawing.Point(4, 22)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage9.Size = New System.Drawing.Size(1028, 590)
        Me.TabPage9.TabIndex = 8
        Me.TabPage9.Text = "Geography"
        Me.TabPage9.UseVisualStyleBackColor = True
        '
        'RichTextBox8
        '
        Me.RichTextBox8.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox8.Location = New System.Drawing.Point(0, 31)
        Me.RichTextBox8.Name = "RichTextBox8"
        Me.RichTextBox8.Size = New System.Drawing.Size(1025, 559)
        Me.RichTextBox8.TabIndex = 1
        Me.RichTextBox8.Text = ""
        '
        'ToolStrip8
        '
        Me.ToolStrip8.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripButton7, Me.OpenToolStripButton7, Me.SaveToolStripButton7, Me.PrintToolStripButton7, Me.toolStripSeparator14, Me.CutToolStripButton7, Me.CopyToolStripButton7, Me.PasteToolStripButton7, Me.toolStripSeparator15, Me.HelpToolStripButton7})
        Me.ToolStrip8.Location = New System.Drawing.Point(3, 3)
        Me.ToolStrip8.Name = "ToolStrip8"
        Me.ToolStrip8.Size = New System.Drawing.Size(1022, 25)
        Me.ToolStrip8.TabIndex = 0
        Me.ToolStrip8.Text = "ToolStrip8"
        '
        'NewToolStripButton7
        '
        Me.NewToolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.NewToolStripButton7.Image = CType(resources.GetObject("NewToolStripButton7.Image"), System.Drawing.Image)
        Me.NewToolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.NewToolStripButton7.Name = "NewToolStripButton7"
        Me.NewToolStripButton7.Size = New System.Drawing.Size(23, 22)
        Me.NewToolStripButton7.Text = "&New"
        '
        'OpenToolStripButton7
        '
        Me.OpenToolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.OpenToolStripButton7.Image = CType(resources.GetObject("OpenToolStripButton7.Image"), System.Drawing.Image)
        Me.OpenToolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.OpenToolStripButton7.Name = "OpenToolStripButton7"
        Me.OpenToolStripButton7.Size = New System.Drawing.Size(23, 22)
        Me.OpenToolStripButton7.Text = "&Open"
        '
        'SaveToolStripButton7
        '
        Me.SaveToolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SaveToolStripButton7.Image = CType(resources.GetObject("SaveToolStripButton7.Image"), System.Drawing.Image)
        Me.SaveToolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SaveToolStripButton7.Name = "SaveToolStripButton7"
        Me.SaveToolStripButton7.Size = New System.Drawing.Size(23, 22)
        Me.SaveToolStripButton7.Text = "&Save"
        '
        'PrintToolStripButton7
        '
        Me.PrintToolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PrintToolStripButton7.Image = CType(resources.GetObject("PrintToolStripButton7.Image"), System.Drawing.Image)
        Me.PrintToolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PrintToolStripButton7.Name = "PrintToolStripButton7"
        Me.PrintToolStripButton7.Size = New System.Drawing.Size(23, 22)
        Me.PrintToolStripButton7.Text = "&Print"
        '
        'toolStripSeparator14
        '
        Me.toolStripSeparator14.Name = "toolStripSeparator14"
        Me.toolStripSeparator14.Size = New System.Drawing.Size(6, 25)
        '
        'CutToolStripButton7
        '
        Me.CutToolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CutToolStripButton7.Image = CType(resources.GetObject("CutToolStripButton7.Image"), System.Drawing.Image)
        Me.CutToolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CutToolStripButton7.Name = "CutToolStripButton7"
        Me.CutToolStripButton7.Size = New System.Drawing.Size(23, 22)
        Me.CutToolStripButton7.Text = "C&ut"
        '
        'CopyToolStripButton7
        '
        Me.CopyToolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CopyToolStripButton7.Image = CType(resources.GetObject("CopyToolStripButton7.Image"), System.Drawing.Image)
        Me.CopyToolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CopyToolStripButton7.Name = "CopyToolStripButton7"
        Me.CopyToolStripButton7.Size = New System.Drawing.Size(23, 22)
        Me.CopyToolStripButton7.Text = "&Copy"
        '
        'PasteToolStripButton7
        '
        Me.PasteToolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PasteToolStripButton7.Image = CType(resources.GetObject("PasteToolStripButton7.Image"), System.Drawing.Image)
        Me.PasteToolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PasteToolStripButton7.Name = "PasteToolStripButton7"
        Me.PasteToolStripButton7.Size = New System.Drawing.Size(23, 22)
        Me.PasteToolStripButton7.Text = "&Paste"
        '
        'toolStripSeparator15
        '
        Me.toolStripSeparator15.Name = "toolStripSeparator15"
        Me.toolStripSeparator15.Size = New System.Drawing.Size(6, 25)
        '
        'HelpToolStripButton7
        '
        Me.HelpToolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.HelpToolStripButton7.Image = CType(resources.GetObject("HelpToolStripButton7.Image"), System.Drawing.Image)
        Me.HelpToolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.HelpToolStripButton7.Name = "HelpToolStripButton7"
        Me.HelpToolStripButton7.Size = New System.Drawing.Size(23, 22)
        Me.HelpToolStripButton7.Text = "He&lp"
        '
        'TabPage10
        '
        Me.TabPage10.Controls.Add(Me.RichTextBox9)
        Me.TabPage10.Controls.Add(Me.ToolStrip9)
        Me.TabPage10.Location = New System.Drawing.Point(4, 22)
        Me.TabPage10.Name = "TabPage10"
        Me.TabPage10.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage10.Size = New System.Drawing.Size(1028, 590)
        Me.TabPage10.TabIndex = 9
        Me.TabPage10.Text = "Language"
        Me.TabPage10.UseVisualStyleBackColor = True
        '
        'RichTextBox9
        '
        Me.RichTextBox9.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox9.Location = New System.Drawing.Point(0, 31)
        Me.RichTextBox9.Name = "RichTextBox9"
        Me.RichTextBox9.Size = New System.Drawing.Size(1025, 556)
        Me.RichTextBox9.TabIndex = 1
        Me.RichTextBox9.Text = ""
        '
        'ToolStrip9
        '
        Me.ToolStrip9.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripButton8, Me.OpenToolStripButton8, Me.SaveToolStripButton8, Me.PrintToolStripButton8, Me.toolStripSeparator16, Me.CutToolStripButton8, Me.CopyToolStripButton8, Me.PasteToolStripButton8, Me.toolStripSeparator17, Me.HelpToolStripButton8})
        Me.ToolStrip9.Location = New System.Drawing.Point(3, 3)
        Me.ToolStrip9.Name = "ToolStrip9"
        Me.ToolStrip9.Size = New System.Drawing.Size(1022, 25)
        Me.ToolStrip9.TabIndex = 0
        Me.ToolStrip9.Text = "ToolStrip9"
        '
        'NewToolStripButton8
        '
        Me.NewToolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.NewToolStripButton8.Image = CType(resources.GetObject("NewToolStripButton8.Image"), System.Drawing.Image)
        Me.NewToolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.NewToolStripButton8.Name = "NewToolStripButton8"
        Me.NewToolStripButton8.Size = New System.Drawing.Size(23, 22)
        Me.NewToolStripButton8.Text = "&New"
        '
        'OpenToolStripButton8
        '
        Me.OpenToolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.OpenToolStripButton8.Image = CType(resources.GetObject("OpenToolStripButton8.Image"), System.Drawing.Image)
        Me.OpenToolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.OpenToolStripButton8.Name = "OpenToolStripButton8"
        Me.OpenToolStripButton8.Size = New System.Drawing.Size(23, 22)
        Me.OpenToolStripButton8.Text = "&Open"
        '
        'SaveToolStripButton8
        '
        Me.SaveToolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SaveToolStripButton8.Image = CType(resources.GetObject("SaveToolStripButton8.Image"), System.Drawing.Image)
        Me.SaveToolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SaveToolStripButton8.Name = "SaveToolStripButton8"
        Me.SaveToolStripButton8.Size = New System.Drawing.Size(23, 22)
        Me.SaveToolStripButton8.Text = "&Save"
        '
        'PrintToolStripButton8
        '
        Me.PrintToolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PrintToolStripButton8.Image = CType(resources.GetObject("PrintToolStripButton8.Image"), System.Drawing.Image)
        Me.PrintToolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PrintToolStripButton8.Name = "PrintToolStripButton8"
        Me.PrintToolStripButton8.Size = New System.Drawing.Size(23, 22)
        Me.PrintToolStripButton8.Text = "&Print"
        '
        'toolStripSeparator16
        '
        Me.toolStripSeparator16.Name = "toolStripSeparator16"
        Me.toolStripSeparator16.Size = New System.Drawing.Size(6, 25)
        '
        'CutToolStripButton8
        '
        Me.CutToolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CutToolStripButton8.Image = CType(resources.GetObject("CutToolStripButton8.Image"), System.Drawing.Image)
        Me.CutToolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CutToolStripButton8.Name = "CutToolStripButton8"
        Me.CutToolStripButton8.Size = New System.Drawing.Size(23, 22)
        Me.CutToolStripButton8.Text = "C&ut"
        '
        'CopyToolStripButton8
        '
        Me.CopyToolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CopyToolStripButton8.Image = CType(resources.GetObject("CopyToolStripButton8.Image"), System.Drawing.Image)
        Me.CopyToolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CopyToolStripButton8.Name = "CopyToolStripButton8"
        Me.CopyToolStripButton8.Size = New System.Drawing.Size(23, 22)
        Me.CopyToolStripButton8.Text = "&Copy"
        '
        'PasteToolStripButton8
        '
        Me.PasteToolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PasteToolStripButton8.Image = CType(resources.GetObject("PasteToolStripButton8.Image"), System.Drawing.Image)
        Me.PasteToolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PasteToolStripButton8.Name = "PasteToolStripButton8"
        Me.PasteToolStripButton8.Size = New System.Drawing.Size(23, 22)
        Me.PasteToolStripButton8.Text = "&Paste"
        '
        'toolStripSeparator17
        '
        Me.toolStripSeparator17.Name = "toolStripSeparator17"
        Me.toolStripSeparator17.Size = New System.Drawing.Size(6, 25)
        '
        'HelpToolStripButton8
        '
        Me.HelpToolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.HelpToolStripButton8.Image = CType(resources.GetObject("HelpToolStripButton8.Image"), System.Drawing.Image)
        Me.HelpToolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.HelpToolStripButton8.Name = "HelpToolStripButton8"
        Me.HelpToolStripButton8.Size = New System.Drawing.Size(23, 22)
        Me.HelpToolStripButton8.Text = "He&lp"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        Me.OpenFileDialog1.Filter = "Text Files (*.txt)|*.txt"
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.Filter = "Text Files (*.txt)|*.txt"
        '
        'OpenFileDialog2
        '
        Me.OpenFileDialog2.FileName = "OpenFileDialog2"
        Me.OpenFileDialog2.Filter = "Text Files (*.txt)|*.txt"
        '
        'SaveFileDialog2
        '
        Me.SaveFileDialog2.Filter = "Text Files (*.txt)|*.txt"
        '
        'OpenFileDialog3
        '
        Me.OpenFileDialog3.FileName = "OpenFileDialog3"
        Me.OpenFileDialog3.Filter = "Text Files (*.txt)|*.txt"
        '
        'SaveFileDialog3
        '
        Me.SaveFileDialog3.Filter = "Text Files (*.txt)|*.txt"
        '
        'OpenFileDialog4
        '
        Me.OpenFileDialog4.FileName = "OpenFileDialog4"
        Me.OpenFileDialog4.Filter = "Text Files (*.txt)|*.txt"
        '
        'SaveFileDialog4
        '
        Me.SaveFileDialog4.Filter = "Text Files (*.txt)|*.txt"
        '
        'OpenFileDialog5
        '
        Me.OpenFileDialog5.FileName = "OpenFileDialog5"
        Me.OpenFileDialog5.Filter = "Text Files (*.txt)|*.txt"
        '
        'SaveFileDialog5
        '
        Me.SaveFileDialog5.Filter = "Text Files (*.txt)|*.txt"
        '
        'OpenFileDialog6
        '
        Me.OpenFileDialog6.FileName = "OpenFileDialog6"
        Me.OpenFileDialog6.Filter = "Text Files (*.txt)|*.txt"
        '
        'SaveFileDialog6
        '
        Me.SaveFileDialog6.Filter = "Text Files (*.txt)|*.txt"
        '
        'OpenFileDialog7
        '
        Me.OpenFileDialog7.FileName = "OpenFileDialog7"
        Me.OpenFileDialog7.Filter = "Text Files (*.txt)|*.txt"
        '
        'SaveFileDialog7
        '
        Me.SaveFileDialog7.Filter = "Text Files (*.txt)|*.txt"
        '
        'OpenFileDialog8
        '
        Me.OpenFileDialog8.FileName = "OpenFileDialog8"
        Me.OpenFileDialog8.Filter = "Text Files (*.txt)|*.txt"
        '
        'SaveFileDialog8
        '
        Me.SaveFileDialog8.Filter = "Text Files (*.txt)|*.txt"
        '
        'OpenFileDialog9
        '
        Me.OpenFileDialog9.FileName = "OpenFileDialog9"
        Me.OpenFileDialog9.Filter = "Text Files (*.txt)|*.txt"
        '
        'SaveFileDialog9
        '
        Me.SaveFileDialog9.Filter = "Text Files (*.txt)|*.txt"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button1.Location = New System.Drawing.Point(945, 3)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Calendar"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'MonthCalendar1
        '
        Me.MonthCalendar1.Location = New System.Drawing.Point(793, 38)
        Me.MonthCalendar1.Name = "MonthCalendar1"
        Me.MonthCalendar1.TabIndex = 3
        Me.MonthCalendar1.Visible = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button2.Location = New System.Drawing.Point(857, 3)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(82, 23)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "Hide Calendar"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(1036, 612)
        Me.Controls.Add(Me.TabControl1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(397, 360)
        Me.Name = "Form1"
        Me.Text = "Study Book 3.1"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.ToolStrip2.ResumeLayout(False)
        Me.ToolStrip2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.ToolStrip3.ResumeLayout(False)
        Me.ToolStrip3.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.ToolStrip4.ResumeLayout(False)
        Me.ToolStrip4.PerformLayout()
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        Me.ToolStrip5.ResumeLayout(False)
        Me.ToolStrip5.PerformLayout()
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage7.PerformLayout()
        Me.ToolStrip6.ResumeLayout(False)
        Me.ToolStrip6.PerformLayout()
        Me.TabPage8.ResumeLayout(False)
        Me.ToolStrip7.ResumeLayout(False)
        Me.ToolStrip7.PerformLayout()
        Me.TabPage9.ResumeLayout(False)
        Me.TabPage9.PerformLayout()
        Me.ToolStrip8.ResumeLayout(False)
        Me.ToolStrip8.PerformLayout()
        Me.TabPage10.ResumeLayout(False)
        Me.TabPage10.PerformLayout()
        Me.ToolStrip9.ResumeLayout(False)
        Me.ToolStrip9.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents TabPage6 As TabPage
    Friend WithEvents TabPage7 As TabPage
    Friend WithEvents TabPage8 As TabPage
    Friend WithEvents TabPage9 As TabPage
    Friend WithEvents TabPage10 As TabPage
    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents NewToolStripButton As ToolStripButton
    Friend WithEvents OpenToolStripButton As ToolStripButton
    Friend WithEvents SaveToolStripButton As ToolStripButton
    Friend WithEvents PrintToolStripButton As ToolStripButton
    Friend WithEvents toolStripSeparator As ToolStripSeparator
    Friend WithEvents CutToolStripButton As ToolStripButton
    Friend WithEvents CopyToolStripButton As ToolStripButton
    Friend WithEvents PasteToolStripButton As ToolStripButton
    Friend WithEvents toolStripSeparator1 As ToolStripSeparator
    Friend WithEvents HelpToolStripButton As ToolStripButton
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents SaveFileDialog1 As SaveFileDialog
    Friend WithEvents ToolStrip2 As ToolStrip
    Friend WithEvents NewToolStripButton1 As ToolStripButton
    Friend WithEvents OpenToolStripButton1 As ToolStripButton
    Friend WithEvents SaveToolStripButton1 As ToolStripButton
    Friend WithEvents PrintToolStripButton1 As ToolStripButton
    Friend WithEvents toolStripSeparator2 As ToolStripSeparator
    Friend WithEvents CutToolStripButton1 As ToolStripButton
    Friend WithEvents CopyToolStripButton1 As ToolStripButton
    Friend WithEvents PasteToolStripButton1 As ToolStripButton
    Friend WithEvents toolStripSeparator3 As ToolStripSeparator
    Friend WithEvents HelpToolStripButton1 As ToolStripButton
    Friend WithEvents RichTextBox2 As RichTextBox
    Friend WithEvents OpenFileDialog2 As OpenFileDialog
    Friend WithEvents SaveFileDialog2 As SaveFileDialog
    Friend WithEvents RichTextBox3 As RichTextBox
    Friend WithEvents ToolStrip3 As ToolStrip
    Friend WithEvents NewToolStripButton2 As ToolStripButton
    Friend WithEvents OpenToolStripButton2 As ToolStripButton
    Friend WithEvents SaveToolStripButton2 As ToolStripButton
    Friend WithEvents PrintToolStripButton2 As ToolStripButton
    Friend WithEvents toolStripSeparator4 As ToolStripSeparator
    Friend WithEvents CutToolStripButton2 As ToolStripButton
    Friend WithEvents CopyToolStripButton2 As ToolStripButton
    Friend WithEvents PasteToolStripButton2 As ToolStripButton
    Friend WithEvents toolStripSeparator5 As ToolStripSeparator
    Friend WithEvents HelpToolStripButton2 As ToolStripButton
    Friend WithEvents OpenFileDialog3 As OpenFileDialog
    Friend WithEvents SaveFileDialog3 As SaveFileDialog
    Friend WithEvents RichTextBox4 As RichTextBox
    Friend WithEvents ToolStrip4 As ToolStrip
    Friend WithEvents NewToolStripButton3 As ToolStripButton
    Friend WithEvents OpenToolStripButton3 As ToolStripButton
    Friend WithEvents SaveToolStripButton3 As ToolStripButton
    Friend WithEvents PrintToolStripButton3 As ToolStripButton
    Friend WithEvents toolStripSeparator6 As ToolStripSeparator
    Friend WithEvents CutToolStripButton3 As ToolStripButton
    Friend WithEvents CopyToolStripButton3 As ToolStripButton
    Friend WithEvents PasteToolStripButton3 As ToolStripButton
    Friend WithEvents toolStripSeparator7 As ToolStripSeparator
    Friend WithEvents HelpToolStripButton3 As ToolStripButton
    Friend WithEvents OpenFileDialog4 As OpenFileDialog
    Friend WithEvents SaveFileDialog4 As SaveFileDialog
    Friend WithEvents RichTextBox5 As RichTextBox
    Friend WithEvents ToolStrip5 As ToolStrip
    Friend WithEvents NewToolStripButton4 As ToolStripButton
    Friend WithEvents OpenToolStripButton4 As ToolStripButton
    Friend WithEvents SaveToolStripButton4 As ToolStripButton
    Friend WithEvents PrintToolStripButton4 As ToolStripButton
    Friend WithEvents toolStripSeparator8 As ToolStripSeparator
    Friend WithEvents CutToolStripButton4 As ToolStripButton
    Friend WithEvents CopyToolStripButton4 As ToolStripButton
    Friend WithEvents PasteToolStripButton4 As ToolStripButton
    Friend WithEvents toolStripSeparator9 As ToolStripSeparator
    Friend WithEvents HelpToolStripButton4 As ToolStripButton
    Friend WithEvents OpenFileDialog5 As OpenFileDialog
    Friend WithEvents SaveFileDialog5 As SaveFileDialog
    Friend WithEvents RichTextBox6 As RichTextBox
    Friend WithEvents ToolStrip6 As ToolStrip
    Friend WithEvents NewToolStripButton5 As ToolStripButton
    Friend WithEvents OpenToolStripButton5 As ToolStripButton
    Friend WithEvents SaveToolStripButton5 As ToolStripButton
    Friend WithEvents PrintToolStripButton5 As ToolStripButton
    Friend WithEvents toolStripSeparator10 As ToolStripSeparator
    Friend WithEvents CutToolStripButton5 As ToolStripButton
    Friend WithEvents CopyToolStripButton5 As ToolStripButton
    Friend WithEvents PasteToolStripButton5 As ToolStripButton
    Friend WithEvents toolStripSeparator11 As ToolStripSeparator
    Friend WithEvents HelpToolStripButton5 As ToolStripButton
    Friend WithEvents OpenFileDialog6 As OpenFileDialog
    Friend WithEvents SaveFileDialog6 As SaveFileDialog
    Friend WithEvents RichTextBox7 As RichTextBox
    Friend WithEvents ToolStrip7 As ToolStrip
    Friend WithEvents NewToolStripButton6 As ToolStripButton
    Friend WithEvents OpenToolStripButton6 As ToolStripButton
    Friend WithEvents SaveToolStripButton6 As ToolStripButton
    Friend WithEvents PrintToolStripButton6 As ToolStripButton
    Friend WithEvents toolStripSeparator12 As ToolStripSeparator
    Friend WithEvents CutToolStripButton6 As ToolStripButton
    Friend WithEvents CopyToolStripButton6 As ToolStripButton
    Friend WithEvents PasteToolStripButton6 As ToolStripButton
    Friend WithEvents toolStripSeparator13 As ToolStripSeparator
    Friend WithEvents HelpToolStripButton6 As ToolStripButton
    Friend WithEvents OpenFileDialog7 As OpenFileDialog
    Friend WithEvents SaveFileDialog7 As SaveFileDialog
    Friend WithEvents RichTextBox8 As RichTextBox
    Friend WithEvents ToolStrip8 As ToolStrip
    Friend WithEvents NewToolStripButton7 As ToolStripButton
    Friend WithEvents OpenToolStripButton7 As ToolStripButton
    Friend WithEvents SaveToolStripButton7 As ToolStripButton
    Friend WithEvents PrintToolStripButton7 As ToolStripButton
    Friend WithEvents toolStripSeparator14 As ToolStripSeparator
    Friend WithEvents CutToolStripButton7 As ToolStripButton
    Friend WithEvents CopyToolStripButton7 As ToolStripButton
    Friend WithEvents PasteToolStripButton7 As ToolStripButton
    Friend WithEvents toolStripSeparator15 As ToolStripSeparator
    Friend WithEvents HelpToolStripButton7 As ToolStripButton
    Friend WithEvents OpenFileDialog8 As OpenFileDialog
    Friend WithEvents SaveFileDialog8 As SaveFileDialog
    Friend WithEvents RichTextBox9 As RichTextBox
    Friend WithEvents ToolStrip9 As ToolStrip
    Friend WithEvents NewToolStripButton8 As ToolStripButton
    Friend WithEvents OpenToolStripButton8 As ToolStripButton
    Friend WithEvents SaveToolStripButton8 As ToolStripButton
    Friend WithEvents PrintToolStripButton8 As ToolStripButton
    Friend WithEvents toolStripSeparator16 As ToolStripSeparator
    Friend WithEvents CutToolStripButton8 As ToolStripButton
    Friend WithEvents CopyToolStripButton8 As ToolStripButton
    Friend WithEvents PasteToolStripButton8 As ToolStripButton
    Friend WithEvents toolStripSeparator17 As ToolStripSeparator
    Friend WithEvents HelpToolStripButton8 As ToolStripButton
    Friend WithEvents OpenFileDialog9 As OpenFileDialog
    Friend WithEvents SaveFileDialog9 As SaveFileDialog
    Friend WithEvents MonthCalendar1 As MonthCalendar
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
End Class
