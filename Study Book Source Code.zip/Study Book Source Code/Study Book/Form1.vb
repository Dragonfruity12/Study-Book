﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub TabPage1_Click(sender As Object, e As EventArgs) Handles TabPage1.Click

    End Sub

    Private Sub NewToolStripButton_Click(sender As Object, e As EventArgs) Handles NewToolStripButton.Click
        RichTextBox1.Clear()
    End Sub

    Private Sub SaveToolStripButton_Click(sender As Object, e As EventArgs) Handles SaveToolStripButton.Click
        SaveFileDialog1.ShowDialog()
    End Sub

    Private Sub OpenToolStripButton_Click(sender As Object, e As EventArgs) Handles OpenToolStripButton.Click
        OpenFileDialog1.ShowDialog()
    End Sub

    Private Sub SaveFileDialog1_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles SaveFileDialog1.FileOk
        My.Computer.FileSystem.WriteAllText(SaveFileDialog1.FileName, RichTextBox1.Text, False)
    End Sub

    Private Sub OpenFileDialog1_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog1.FileOk
        RichTextBox1.Text = My.Computer.FileSystem.ReadAllText(OpenFileDialog1.FileName)
    End Sub

    Private Sub CutToolStripButton_Click(sender As Object, e As EventArgs) Handles CutToolStripButton.Click
        RichTextBox1.Cut()
    End Sub

    Private Sub CopyToolStripButton_Click(sender As Object, e As EventArgs) Handles CopyToolStripButton.Click
        RichTextBox1.Copy()
    End Sub

    Private Sub PasteToolStripButton_Click(sender As Object, e As EventArgs) Handles PasteToolStripButton.Click
        RichTextBox1.Paste()
    End Sub

    Private Sub HelpToolStripButton_Click(sender As Object, e As EventArgs) Handles HelpToolStripButton.Click
        MsgBox("Study Book, program made by students for students.              Developers: Dragon Fruity                                                                             Icon made by icons8.com")
    End Sub

    Private Sub NewToolStripButton1_Click(sender As Object, e As EventArgs) Handles NewToolStripButton1.Click
        RichTextBox2.Clear()
    End Sub

    Private Sub HelpToolStripButton1_Click(sender As Object, e As EventArgs) Handles HelpToolStripButton1.Click
        MsgBox("Study Book, program made by students for students.              Developers: Dragon Fruity                                                                             Icon made by icons8.com")
    End Sub

    Private Sub OpenToolStripButton1_Click(sender As Object, e As EventArgs) Handles OpenToolStripButton1.Click
        OpenFileDialog2.ShowDialog()
    End Sub

    Private Sub OpenFileDialog2_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog2.FileOk
        RichTextBox2.Text = My.Computer.FileSystem.ReadAllText(OpenFileDialog2.FileName)
    End Sub

    Private Sub SaveToolStripButton1_Click(sender As Object, e As EventArgs) Handles SaveToolStripButton1.Click
        SaveFileDialog2.ShowDialog()
    End Sub

    Private Sub SaveFileDialog2_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles SaveFileDialog2.FileOk
        My.Computer.FileSystem.WriteAllText(SaveFileDialog2.FileName, RichTextBox2.Text, False)
    End Sub

    Private Sub RichTextBox1_TextChanged(sender As Object, e As EventArgs) Handles RichTextBox1.TextChanged

    End Sub

    Private Sub CutToolStripButton1_Click(sender As Object, e As EventArgs) Handles CutToolStripButton1.Click
        RichTextBox2.Cut()
    End Sub

    Private Sub CopyToolStripButton1_Click(sender As Object, e As EventArgs) Handles CopyToolStripButton1.Click
        RichTextBox2.Copy()
    End Sub

    Private Sub PasteToolStripButton1_Click(sender As Object, e As EventArgs) Handles PasteToolStripButton1.Click
        RichTextBox2.Paste()
    End Sub

    Private Sub OpenFileDialog3_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog3.FileOk
        RichTextBox3.Text = My.Computer.FileSystem.ReadAllText(OpenFileDialog3.FileName)
    End Sub

    Private Sub SaveFileDialog3_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles SaveFileDialog3.FileOk
        My.Computer.FileSystem.WriteAllText(SaveFileDialog3.FileName, RichTextBox3.Text, False)
    End Sub

    Private Sub NewToolStripButton2_Click(sender As Object, e As EventArgs) Handles NewToolStripButton2.Click
        RichTextBox3.Clear()
    End Sub

    Private Sub OpenToolStripButton2_Click(sender As Object, e As EventArgs) Handles OpenToolStripButton2.Click
        OpenFileDialog3.ShowDialog()
    End Sub

    Private Sub SaveToolStripButton2_Click(sender As Object, e As EventArgs) Handles SaveToolStripButton2.Click
        SaveFileDialog3.ShowDialog()
    End Sub

    Private Sub CutToolStripButton2_Click(sender As Object, e As EventArgs) Handles CutToolStripButton2.Click
        RichTextBox3.Cut()
    End Sub

    Private Sub CopyToolStripButton2_Click(sender As Object, e As EventArgs) Handles CopyToolStripButton2.Click
        RichTextBox3.Copy()
    End Sub

    Private Sub PasteToolStripButton2_Click(sender As Object, e As EventArgs) Handles PasteToolStripButton2.Click
        RichTextBox3.Paste()
    End Sub

    Private Sub HelpToolStripButton2_Click(sender As Object, e As EventArgs) Handles HelpToolStripButton2.Click
        MsgBox("Study Book, program made by students for students.              Developers: Dragon Fruity                                                                             Icon made by icons8.com")
    End Sub

    Private Sub OpenToolStripButton3_Click(sender As Object, e As EventArgs)
        OpenFileDialog3.ShowDialog()
    End Sub

    Private Sub SaveToolStripButton3_Click(sender As Object, e As EventArgs)
        SaveFileDialog3.ShowDialog()
    End Sub

    Private Sub HelpToolStripButton3_Click(sender As Object, e As EventArgs)
        MsgBox("Study Book, program made by students for students.              Developers: Dragon Fruity                                                                             Icon made by icons8.com")
    End Sub

    Private Sub NewToolStripButton3_Click(sender As Object, e As EventArgs) Handles NewToolStripButton3.Click
        RichTextBox4.Clear()
    End Sub

    Private Sub OpenFileDialog4_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog4.FileOk
        RichTextBox4.Text = My.Computer.FileSystem.ReadAllText(OpenFileDialog4.FileName)
    End Sub

    Private Sub SaveFileDialog4_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles SaveFileDialog4.FileOk
        My.Computer.FileSystem.WriteAllText(SaveFileDialog4.FileName, RichTextBox4.Text, False)
    End Sub

    Private Sub OpenToolStripButton3_Click_1(sender As Object, e As EventArgs) Handles OpenToolStripButton3.Click
        OpenFileDialog4.ShowDialog()
    End Sub

    Private Sub SaveToolStripButton3_Click_1(sender As Object, e As EventArgs) Handles SaveToolStripButton3.Click
        SaveFileDialog4.ShowDialog()
    End Sub

    Private Sub CutToolStripButton3_Click(sender As Object, e As EventArgs) Handles CutToolStripButton3.Click
        RichTextBox4.Cut()
    End Sub

    Private Sub CopyToolStripButton3_Click(sender As Object, e As EventArgs) Handles CopyToolStripButton3.Click
        RichTextBox4.Copy()
    End Sub

    Private Sub PasteToolStripButton3_Click(sender As Object, e As EventArgs) Handles PasteToolStripButton3.Click
        RichTextBox4.Paste()
    End Sub

    Private Sub HelpToolStripButton3_Click_1(sender As Object, e As EventArgs) Handles HelpToolStripButton3.Click
        MsgBox("Study Book, program made by students for students.              Developers: Dragon Fruity                                                                             Icon made by icons8.com")
    End Sub

    Private Sub NewToolStripButton4_Click(sender As Object, e As EventArgs) Handles NewToolStripButton4.Click
        RichTextBox5.Clear()
    End Sub

    Private Sub OpenFileDialog5_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog5.FileOk
        RichTextBox5.Text = My.Computer.FileSystem.ReadAllText(OpenFileDialog5.FileName)
    End Sub

    Private Sub SaveFileDialog5_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles SaveFileDialog5.FileOk
        My.Computer.FileSystem.WriteAllText(SaveFileDialog5.FileName, RichTextBox5.Text, False)
    End Sub

    Private Sub OpenToolStripButton4_Click(sender As Object, e As EventArgs) Handles OpenToolStripButton4.Click
        OpenFileDialog5.ShowDialog()
    End Sub

    Private Sub SaveToolStripButton4_Click(sender As Object, e As EventArgs) Handles SaveToolStripButton4.Click
        SaveFileDialog5.ShowDialog()
    End Sub

    Private Sub CutToolStripButton4_Click(sender As Object, e As EventArgs) Handles CutToolStripButton4.Click
        RichTextBox5.Cut()
    End Sub

    Private Sub CopyToolStripButton4_Click(sender As Object, e As EventArgs) Handles CopyToolStripButton4.Click
        RichTextBox5.Copy()
    End Sub

    Private Sub PasteToolStripButton4_Click(sender As Object, e As EventArgs) Handles PasteToolStripButton4.Click
        RichTextBox5.Paste()
    End Sub

    Private Sub HelpToolStripButton4_Click(sender As Object, e As EventArgs) Handles HelpToolStripButton4.Click
        MsgBox("Study Book, program made by students for students.              Developers: Dragon Fruity                                                                             Icon made by icons8.com")
    End Sub

    Private Sub NewToolStripButton5_Click(sender As Object, e As EventArgs) Handles NewToolStripButton5.Click
        RichTextBox6.Clear()
    End Sub

    Private Sub OpenFileDialog6_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog6.FileOk
        RichTextBox6.Text = My.Computer.FileSystem.ReadAllText(OpenFileDialog6.FileName)
    End Sub

    Private Sub SaveFileDialog6_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles SaveFileDialog6.FileOk
        My.Computer.FileSystem.WriteAllText(SaveFileDialog6.FileName, RichTextBox6.Text, False)
    End Sub

    Private Sub OpenToolStripButton5_Click(sender As Object, e As EventArgs) Handles OpenToolStripButton5.Click
        OpenFileDialog6.ShowDialog()
    End Sub

    Private Sub SaveToolStripButton5_Click(sender As Object, e As EventArgs) Handles SaveToolStripButton5.Click
        SaveFileDialog6.ShowDialog()
    End Sub

    Private Sub CutToolStripButton5_Click(sender As Object, e As EventArgs) Handles CutToolStripButton5.Click
        RichTextBox6.Cut()
    End Sub

    Private Sub CopyToolStripButton5_Click(sender As Object, e As EventArgs) Handles CopyToolStripButton5.Click
        RichTextBox6.Copy()
    End Sub

    Private Sub PasteToolStripButton5_Click(sender As Object, e As EventArgs) Handles PasteToolStripButton5.Click
        RichTextBox6.Paste()
    End Sub

    Private Sub RichTextBox7_TextChanged(sender As Object, e As EventArgs) Handles RichTextBox7.TextChanged

    End Sub

    Private Sub NewToolStripButton6_Click(sender As Object, e As EventArgs) Handles NewToolStripButton6.Click
        RichTextBox7.Clear()
    End Sub

    Private Sub CutToolStripButton6_Click(sender As Object, e As EventArgs) Handles CutToolStripButton6.Click
        RichTextBox7.Cut()
    End Sub

    Private Sub CopyToolStripButton6_Click(sender As Object, e As EventArgs) Handles CopyToolStripButton6.Click
        RichTextBox7.Copy()
    End Sub

    Private Sub PasteToolStripButton6_Click(sender As Object, e As EventArgs) Handles PasteToolStripButton6.Click
        RichTextBox7.Paste()
    End Sub

    Private Sub HelpToolStripButton5_Click(sender As Object, e As EventArgs) Handles HelpToolStripButton5.Click
        MsgBox("Study Book, program made by students for students.              Developers: Dragon Fruity                                                                             Icon made by icons8.com")
    End Sub

    Private Sub HelpToolStripButton6_Click(sender As Object, e As EventArgs) Handles HelpToolStripButton6.Click
        MsgBox("Study Book, program made by students for students.              Developers: Dragon Fruity                                                                             Icon made by icons8.com")
    End Sub

    Private Sub OpenFileDialog7_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog7.FileOk
        RichTextBox7.Text = My.Computer.FileSystem.ReadAllText(OpenFileDialog7.FileName)
    End Sub

    Private Sub SaveFileDialog7_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles SaveFileDialog7.FileOk
        My.Computer.FileSystem.WriteAllText(SaveFileDialog7.FileName, RichTextBox7.Text, False)
    End Sub

    Private Sub OpenToolStripButton6_Click(sender As Object, e As EventArgs) Handles OpenToolStripButton6.Click
        OpenFileDialog7.ShowDialog()
    End Sub

    Private Sub SaveToolStripButton6_Click(sender As Object, e As EventArgs) Handles SaveToolStripButton6.Click
        SaveFileDialog7.ShowDialog()
    End Sub

    Private Sub NewToolStripButton7_Click(sender As Object, e As EventArgs) Handles NewToolStripButton7.Click
        RichTextBox8.Clear()
    End Sub

    Private Sub HelpToolStripButton7_Click(sender As Object, e As EventArgs) Handles HelpToolStripButton7.Click
        MsgBox("Study Book, program made by students for students.              Developers: Dragon Fruity                                                                             Icon made by icons8.com")
    End Sub

    Private Sub CutToolStripButton7_Click(sender As Object, e As EventArgs) Handles CutToolStripButton7.Click
        RichTextBox8.Cut()
    End Sub

    Private Sub CopyToolStripButton7_Click(sender As Object, e As EventArgs) Handles CopyToolStripButton7.Click
        RichTextBox8.Copy()
    End Sub

    Private Sub PasteToolStripButton7_Click(sender As Object, e As EventArgs) Handles PasteToolStripButton7.Click
        RichTextBox8.Paste()
    End Sub

    Private Sub OpenFileDialog8_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog8.FileOk
        RichTextBox8.Text = My.Computer.FileSystem.ReadAllText(OpenFileDialog8.FileName)
    End Sub

    Private Sub SaveFileDialog8_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles SaveFileDialog8.FileOk
        My.Computer.FileSystem.WriteAllText(SaveFileDialog8.FileName, RichTextBox8.Text, False)
    End Sub

    Private Sub OpenToolStripButton7_Click(sender As Object, e As EventArgs) Handles OpenToolStripButton7.Click
        OpenFileDialog8.ShowDialog()
    End Sub

    Private Sub SaveToolStripButton7_Click(sender As Object, e As EventArgs) Handles SaveToolStripButton7.Click
        SaveFileDialog8.ShowDialog()
    End Sub

    Private Sub NewToolStripButton8_Click(sender As Object, e As EventArgs) Handles NewToolStripButton8.Click
        RichTextBox9.Clear()
    End Sub

    Private Sub CutToolStripButton8_Click(sender As Object, e As EventArgs) Handles CutToolStripButton8.Click
        RichTextBox9.Cut()
    End Sub

    Private Sub CopyToolStripButton8_Click(sender As Object, e As EventArgs) Handles CopyToolStripButton8.Click
        RichTextBox9.Copy()
    End Sub

    Private Sub PasteToolStripButton8_Click(sender As Object, e As EventArgs) Handles PasteToolStripButton8.Click
        RichTextBox9.Paste()
    End Sub

    Private Sub HelpToolStripButton8_Click(sender As Object, e As EventArgs) Handles HelpToolStripButton8.Click
        MsgBox("Study Book, program made by students for students.              Developers: Dragon Fruity                                                                             Icon made by icons8.com")
    End Sub

    Private Sub OpenFileDialog9_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog9.FileOk
        RichTextBox9.Text = My.Computer.FileSystem.ReadAllText(OpenFileDialog9.FileName)
    End Sub

    Private Sub SaveFileDialog9_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles SaveFileDialog9.FileOk
        My.Computer.FileSystem.WriteAllText(SaveFileDialog9.FileName, RichTextBox9.Text, False)
    End Sub

    Private Sub OpenToolStripButton8_Click(sender As Object, e As EventArgs) Handles OpenToolStripButton8.Click
        OpenFileDialog9.ShowDialog()
    End Sub

    Private Sub SaveToolStripButton8_Click(sender As Object, e As EventArgs) Handles SaveToolStripButton8.Click
        SaveFileDialog9.ShowDialog()
    End Sub

    Private Sub MonthCalendar1_DateChanged(sender As Object, e As DateRangeEventArgs) Handles MonthCalendar1.DateChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        MonthCalendar1.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        MonthCalendar1.Hide()
    End Sub
End Class
